I love you omg
Thank you so much for purchasing this asset! (or being a Patreon! <3)

The tile size should be exactly 16x16