First is the file thief.ttf, a True Type Font I have created based on the Thief logo. It features capital and lower case letters, as well as the "Glyphs" in place of the "#$%^&*" keys. I released this font over a year ago on the Eidos Thief forums where I used to be a regular, and it got a good response. I am giving these to you with permission to make them available to the fans.

 

Next is something I've never seen attempted before, let alone done so well. (Not to toot my own horn...) This will gladly occupy some space in the fan gallery. It is of course my custom Garrett figure. It is more than an action figure, as it is made of a 12" doll.

 

The clothing was designed by me based on a screen shot (included: garrett.jpg) which is where I went into a well lit area and threw the scouting orb to my feet. I turned around to see me, then captured the screen. After designed and drawn out and cut, my girlfriend hand sewed it together for me.

 

The costume consists of a grey undershirt, black pants, and navy blue tunic. A black belt with a gold buckle is around his waist. His boots are actually Darth Sidious' boots from the 12" star wars figure. His gloves have not been completed yet. In some scenes he is wearing his cloak, which is and edited (hemmed) Darth Sidious robe. I cut off the arms and sewed the armholes shut. It gives a nice square shoulder look to it this way.

 

Now onto his weapons;

 

First we have the bow (bow.jpg), which is a working replication of his own. In Thief; tDP I took some screenshots of the bow, quiver, and sword from the training level for reference. The bow was hand carved and sanded by me, painted a dark woodly brown and given a real elastic band. (yes, the bow actually works.) Around the grip I used a leather strap wrapped around the bow.

 

Next are the arrows; (arrows.jpg)

 

From left to right;

Rope Arrow, Broadhead Arrow, Water Arrow, Vine Arrow, Moss Arrow, Noisemaker, and Fire Arrow

Rope and Vine actually have strings which unravel like ropes. Noisemaker doesn't really make noise. :) Vine and Moss arrow are treated with a rough texture as if they are plant stems or something. Fire arrow is my version which has a match head at the tip so it really lights. Actual replication of fire arrow in progress.

 

Quiver (as seen in bybox.jpg)

Wraps around Garret over or under his cloak. Holds his 10 arrows perfectly.

 

Sword (not shown) is actually an Excalibur sword mini replica I have which looks virtually identical to Garrett's.

 

Backjack not created yet; will probably carve out of wood.

 

Last is the Money Pouch (moneypouch.jpg) which is used to hold Garrett's loot. Attaches to his belt.

 

 

So a recap;

 

-----------

Figure-----

-----------

 

bybox.jpg - full picture in cloak with arrows equipped standing by T:tdp, T:G, and T2.

closecape - With cloak standing still (as he would be in shadows).

garrett.jpg - comparison of screenshot and figure

bow.jpg - bow comparison mine vs. screenshot

arrows.jpg - all the arrows

moneypouch.jpg - the loot pouch

 

-----------

Font-------

-----------

 

thief.ttf - the true type font

fontprev.jpg - the preview picture of the font in action. (complete with glyphs)

